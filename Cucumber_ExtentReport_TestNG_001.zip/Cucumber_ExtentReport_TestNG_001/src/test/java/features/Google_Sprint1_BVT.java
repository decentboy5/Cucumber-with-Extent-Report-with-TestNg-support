package features;

import java.io.File;


import org.junit.runner.RunWith;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;

import com.cucumber.listener.ExtentProperties;
import com.cucumber.listener.Reporter;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;
import eZLM.Automation.Accelerators.Report;


/**
 * TestRunner - Is the class used to Run the All features files defined in "src/test/resources location .
 * */
/*
@RunWith(Cucumber.class)
@CucumberOptions(features={"src/test/resources/features/TLM"},format={"json:target/cucumber.json","html:target/html"})

public class TestRunner{

	

	
}*/



//@RunWith(Cucumber.class)
@CucumberOptions(
		features={"src/test/resources/features/Google/GoogleHompage.feature"},
		glue = {"features.StepDefinitions"},
		plugin = {"com.cucumber.listener.ExtentCucumberFormatter:output/report.html"})

public class Google_Sprint1_BVT extends AbstractTestNGCucumberTests{

	public static boolean Cleanup=true;
	
	 @BeforeClass
	    public static void setup() {
	        ExtentProperties extentProperties = ExtentProperties.INSTANCE;
	        extentProperties.setReportPath("output/myreport.html");
	    }

	    @AfterClass
	    public static void teardown() {
	        Reporter.loadXMLConfig(new File("src/test/resources/extent-config.xml"));
	        Reporter.setSystemInfo("user", System.getProperty("user.name"));
	        Reporter.setSystemInfo("os", "Mac OSX");
	        Reporter.setTestRunnerOutput("Sample test runner output message \n");
	    	Report.SendReportEmail();
	        
	    }
	
}




