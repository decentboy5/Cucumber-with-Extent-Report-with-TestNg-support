package eZLM.Automation.Utilities;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

public class ConfiguratorFileSupport {
	static Properties props = new Properties();
	static String propertyFile;
	static String strValue;

	public ConfiguratorFileSupport(String propertyFile) {
		ConfiguratorFileSupport.propertyFile = propertyFile;
	}

	/**
	 * getProperty : Used to get the Values from from Our Configuration file. *
	 * 
	 * @param :
	 *            strKey - Any Property Name Mentioned in
	 *            TLMConfiguration.properties File
	 */
	public static String getProperty(String strKey) {
		try {
			File f = new File(propertyFile);
			if (f.exists()) {
				FileInputStream in = new FileInputStream(f);
				props.load(in);
				strValue = props.getProperty(strKey);
				in.close();
			} else
				System.out.println("File not found!");
		} catch (Exception e) {
			System.out.println(e);
		}
		return strValue;
	}

	/**
	 * setProperty : Used to Modify the Values from from Our Configuration file.
	 * *
	 * 
	 * @param :
	 *            strKey - Any Property Name Mentioned in
	 *            TLMConfiguration.properties File
	 * @param :
	 *            strValue - new value for the existing keys
	 */
	public void setProperty(String strKey, String strValue) throws Throwable {
		try {
			File f = new File(propertyFile);
			if (f.exists()) {
				FileInputStream in = new FileInputStream(f);
				props.load(in);
				props.setProperty(strKey, strValue);
				props.store(new FileOutputStream(propertyFile), null);
				in.close();
			} else {
				System.out.println("File not found!");
			}
		} catch (Exception e) {
			System.out.println(e);
		}
	}

	
	
	/**
	 * RemoveProperty : Used to Modify the Values from from Our Configuration file.
	 * *
	 * 
	 * @param :
	 *            strKey - Any Property Name Mentioned in
	 *            TLMConfiguration.properties File
	 * @param :
	 *            strValue - new value for the existing keys
	 */
	public void removeProperty(String strKey) {
		try {
			File f = new File(propertyFile);
			if (f.exists()) {
				FileInputStream in = new FileInputStream(f);
				props.load(in);
				props.remove(strKey);
				props.store(new FileOutputStream(propertyFile), null);
				in.close();
			} else
				System.out.println("File not found!");
		} catch (Exception e) {
			System.out.println(e);
		}

	}

}
