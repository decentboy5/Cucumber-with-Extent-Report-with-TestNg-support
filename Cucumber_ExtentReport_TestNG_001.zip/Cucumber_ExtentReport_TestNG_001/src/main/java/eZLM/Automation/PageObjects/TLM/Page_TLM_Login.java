package eZLM.Automation.PageObjects.TLM;

import eZLM.Automation.Utilities.PageObjectRepository;

public class Page_TLM_Login {

	public static String Admin_login_link =PageObjectRepository.getProperty("TLM_LoginPage", "Admin_login_link");
	
	public static String USER_ID=  PageObjectRepository.getProperty("TLM_LoginPage", "USER_ID");
	
	public static String USER_ID_Submit_Button =  PageObjectRepository.getProperty("TLM_LoginPage", "USER_ID_Submit_Button");
	
	public static String TLM_UserID_TextBox	= PageObjectRepository.getProperty("TLM_LoginPage", "TLM_UserID_TextBox");
	
	public static String TLM__Password_TextBox	= PageObjectRepository.getProperty("TLM_LoginPage", "TLM__Password_TextBox");
	
	public static String Img_ADP_Logo	= PageObjectRepository.getProperty("TLM_LoginPage", "Img_ADP_Logo");
	
	public static String Button_Submit  = PageObjectRepository.getProperty("TLM_LoginPage", "Button_Submit");
}
