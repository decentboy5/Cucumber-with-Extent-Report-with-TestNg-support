package eZLM.Automation.PageObjects.WFN;

public class WFN_LoginPage_Objects {

}
