package eZLM.Automation.PageObjects.TLM;

import eZLM.Automation.Utilities.PageObjectRepository;

public class Page_TLM_HomePage {
	
	public static String searchclinet=PageObjectRepository.getProperty("TLM_HomePage", "UserName");

	
}
