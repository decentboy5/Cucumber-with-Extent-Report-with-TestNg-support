package eZLM.Automation.BusinessComponents.Common.TLM;

import eZLM.Automation.Accelerators.Browser;
import eZLM.Automation.PageObjects.TLM.Page_TLM_Login;

public class Login_TLM  {

	

	
	/** Used to Login in TLM Application AS UA User 
	 * 
	 * @param URL  - Application URL 
	 * @param timeout
	 * @param Username
	 * @param Password
	 */
	public static void LogInto_TLM_AsUaUser(String URL, String Username, String Password) {
		// TODO Auto-generated method stub

		Browser.Open(URL);
		

	}
	public static void LogInto_TLM_AsEmployee(String URL, String Username, String Password) {
		// TODO Auto-generated method stub

		Browser.Open(URL);
		Browser.Type(Page_TLM_Login.TLM_UserID_TextBox, Username, "USRD ID Field");
		Browser.Type(Page_TLM_Login.TLM__Password_TextBox, Password, "Password Filed");
		Browser.Click(Page_TLM_Login.Button_Submit, "Submit Button in Login Page");
		Browser.WaitForElement(Page_TLM_Login.Img_ADP_Logo, 1,"ADP Logo");
		
			
	}
	
	
	public static void LogInto_TLM_AsSupervisor(String URL, String Username, String Password) {
		// TODO Auto-generated method stub

		Browser.Open(URL);
		Browser.Type(Page_TLM_Login.TLM_UserID_TextBox, Username, "USRD ID Field");
		Browser.Type(Page_TLM_Login.TLM__Password_TextBox, Password, "Password Filed");
		Browser.Click(Page_TLM_Login.Button_Submit, "Submit Button in Login Page");
		Browser.WaitForElement(Page_TLM_Login.Img_ADP_Logo, 1,"ADP Logo");
			
	}
	
	
	public static void LogInto_TLM_AsPractitioner(String URL, String Username, String Password) {
		// TODO Auto-generated method stub

		Browser.Open(URL);
		

	}


}
