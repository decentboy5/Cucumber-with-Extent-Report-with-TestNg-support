package eZLM.Automation.BusinessComponents.TimeCard;

public class TimeCardEdit {

}
