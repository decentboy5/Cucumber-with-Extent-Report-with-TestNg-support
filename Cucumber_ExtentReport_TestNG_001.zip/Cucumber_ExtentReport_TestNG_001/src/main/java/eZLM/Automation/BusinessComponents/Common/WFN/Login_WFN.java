package eZLM.Automation.BusinessComponents.Common.WFN;

import eZLM.Automation.Accelerators.Browser;

public class Login_WFN extends Browser{

	
	public static void LogInto_WFN_AsUaUser(String URL, String Username, String Password) {


		Open(URL);
		

	}
	public static void LogInto_WFN_AsEmployee(String URL, String Username, String Password) {
	

		Open(URL);
		
	
	}
	
	public static void LogInto_WFN_AsSupervisor(String URL, String Username, String Password) {
		// TODO Auto-generated method stub

		Open(URL);
			
	}
	
	
	
	public static void LogInto_WFN_AsPractitioner(String URL, String Username, String Password) {
		

		Open(URL);
		

	}
}
